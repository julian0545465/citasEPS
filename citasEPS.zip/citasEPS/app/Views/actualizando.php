










<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

   
    <title>Actualizar Usuario</title>
</head>
<body>


  <style>


    
body{
    background: #ffffff;
    font-family: "Roboto", sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;

}
.login-page{
    width: 360px;
    padding: 8% 0 0;
    margin: auto;
}
.form{
    position: relative;
    z-index: 1;
    background: #ffffff;
    border-radius: 8px;
    max-width: 360px;
    margin: 0 auto 100px;
    padding: 45px;
    text-align: center;
    box-shadow: 0 15px 30px rgba(0,0,0,0.213);
}
.form input{
    font-family: "Roboto", sans-serif;
    outline: 0;
    border-radius: 8px;
    background: #f2f2f2;
    width: 100%;
    border: 0;
    margin: 0 0 15px;
    padding: 15px;
    box-sizing: border-box;
    font-size: 14px;    
}
.form button{
    font-family: "Roboto", sans-serif;
    text-transform: uppercase;
    border-radius: 8px;
    outline: 0;
    background: #8085fe;
    width: 100%;
    border: 0;
    padding: 15px;
    color: #ffffff;
    font-size: 14px;
    -webkit-transition: all 0.3 ease;
    transition: all 0.3 ease;
    cursor: pointer;
}
.form button:hover, .form button:active, .form button:focus{
    background: #6c71f9;

}
.form .message{
    margin: 15px 0 0;
    color: #b3b3b3;
    font-size: 12px;
}
.form .message a{
    color: #8085fe;
    text-decoration: none;
}
.title{
    font-family: 'Poppins', sans-serif;
}
  </style>



    <nav class="navbar bg-body-tertiary fixed-top">
        <div class="container-fluid">
            <strong><label >Actualizar datos de: <?= $usuario['nombre'] ?></label></strong>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
              <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menú</h5>
              <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#">Inicio</a>
                </li>
             
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Citas
                  </a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="consulCita.html">Consultar Clientes</a></li>
                    <li><a class="dropdown-item" href="#"></a></li>
                    <li>
                      <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="#"></a></li>
                  </ul>
                </li>
              </ul>
             
            </div>
          </div>
        </div>
      </nav>




   <div class="login-page">
    <div class="form">
        <strong><label>ACTUALIZAR</label></strong>
        <br>
        <br>
        <br>    
        <form action="<?= base_url('factualizar'); ?>" method="POST" class="login-form">

        <input type="number" hidden name="cedula" value="<?= $usuario['cedula'] ?>">
        <input type="text" class="form-control" id="nombre" name="nombre" value="<?= $usuario['nombre'] ?>" required aria-describedby="emailHelp" placeholder="Nombre">
        <input type="text" class="form-control" id="apellido" name="apellido" value="<?= $usuario['apellido'] ?>" required aria-describedby="emailHelp" placeholder="Apellido">
        <input type="text" class="form-control" id="sexo" name="sexo" value="<?= $usuario['sexo'] ?>" required aria-describedby="emailHelp" placeholder="Sexo">
        <input type="number" class="form-control" id="edad" name="edad" value="<?= $usuario['edad'] ?>" required aria-describedby="emailHelp"  placeholder="Edad">
        <input type="text" class="form-control" id="telefono" name="telefono" value="<?= $usuario['telefono'] ?>" required aria-describedby="emailHelp" placeholder="Telefono">
        <input type="text" class="form-control" id="correo" name="correo" value="<?= $usuario['correo'] ?>" required aria-describedby="emailHelp" placeholder="Correo">
        <input type="text" class="form-control" id="contraseña" name="contraseña" value="<?= $usuario['contraseña'] ?>" required aria-describedby="emailHelp" placeholder="Contraseña">


            <button >Actualizar</button>
           
        </form>


    </div>
   </div>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</body>
</html>






          